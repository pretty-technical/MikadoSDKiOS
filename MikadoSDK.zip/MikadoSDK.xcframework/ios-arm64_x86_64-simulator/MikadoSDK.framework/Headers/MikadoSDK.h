//
//  MikadoSDK.h
//  MikadoSDK
//
//  Created by TR64UV on 17/08/2020.
//  Copyright © 2020 Pretty Technical. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MikadoSDK.
FOUNDATION_EXPORT double MikadoSDKVersionNumber;

//! Project version string for MikadoSDK.
FOUNDATION_EXPORT const unsigned char MikadoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MikadoSDK/PublicHeader.h>


