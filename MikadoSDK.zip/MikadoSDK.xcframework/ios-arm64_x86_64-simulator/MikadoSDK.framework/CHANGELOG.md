## Version 0.0.6
### Features
- Architect fix
- Game list now have pagination feature
- We can now ask for the get balance

## Version 0.0.5
### Features
-  Distribution binary warning flag fix

## Version 0.0.4
### Features
-  Set the environment target for MikadoSDK
### Fixes
- Change environment schemes 

## Version 0.0.3
### Features
-  Mikado login
-  Mikado Sign Up
-  Mikado Game List
-  Mikado Game Launch

